import Trade from "../screen/Trade";

export default function Home(props:any) {
  return <Trade query=""/>
}