import React, { useState, useEffect } from "react";
import { Avatar, Card } from "antd";
import { priceRequest } from '../store/price/actions';
interface Props {
  isShow : string;
}

const { Meta } = Card;

const CurrencyCard = ({isShow}: Props) => {
  const [loading, setLoading] = useState(true);

  useEffect(()=> {
    setLoading(true)
    initialFunc();
  },[isShow])

  const initialFunc = async () => {
    priceRequest({params:{symbol : isShow}});
    setTimeout(()=>{
      setLoading(false);
    },1000)
  };
  return (
    <Card className="inner-card" loading={loading}>
    <Meta
      avatar={<Avatar src="https://storage.googleapis.com/satang-pro/public/assets/icons/coins/btc.png" />}
      title={isShow?.replace('_','/') || "BTC/THB"}
      description="Bitcoin"
    />
    <div className="middle-currency">฿725,119.99</div>
    <div className="footer-card">Volume : {'923,170.47'}</div>
  </Card>
  );
};



export default CurrencyCard;
