import React from "react";

type Props = {};

export default function Footer({}: Props) {
  return <footer>Milo Anurak Kiwphukiaw 1996 : Software Engineer 2023</footer>;
}
